# Education Hub

Education Hub is a student management system.

## Features
- Admin dashboard
- Student dashboard
- Notice management
- Result management

## How to use
1. Upload to GitHub
2. Open index.html
3. Navigate through dashboard

## Technology
- HTML
- CSS
- Bootstrap

## Author
Your Name
